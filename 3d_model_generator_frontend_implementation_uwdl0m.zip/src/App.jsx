import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import ModelViewer from './pages/ModelViewer';
import Dashboard from './pages/Dashboard';

const App = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/viewer" element={<ModelViewer />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
      <Toaster position="bottom-right" />
    </div>
  );
};

export default App;
