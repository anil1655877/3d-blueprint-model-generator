import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRightIcon } from '@heroicons/react/24/outline';

const Home = () => {
  return (
    <div className="min-h-screen pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Transform Your 2D Blueprints into
              <span className="text-blue-600"> Interactive 3D Models</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Using advanced AI technology to convert architectural drawings into detailed 3D construction models
            </p>
            
            <Link
              to="/dashboard"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              Get Started
              <ArrowRightIcon className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            <FeatureCard
              title="AI-Powered Conversion"
              description="Advanced machine learning algorithms detect architectural features automatically"
              icon="🤖"
            />
            <FeatureCard
              title="Real-time 3D Preview"
              description="Interactive 3D visualization with customization options"
              icon="🎮"
            />
            <FeatureCard
              title="Multiple Export Formats"
              description="Export your models in OBJ, STL formats compatible with major 3D software"
              icon="💾"
            />
          </motion.div>
        </div>
      </div>
    </div>
  );
};

const FeatureCard = ({ title, description, icon }) => (
  <motion.div
    whileHover={{ scale: 1.05 }}
    className="p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow"
  >
    <div className="text-4xl mb-4">{icon}</div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </motion.div>
);

export default Home;
